#!/bin/csh

csh preprocess.sh

./process.x
