import torch
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib
from matplotlib import cm
import math


for j in range(1):

	data = np.loadtxt('rot'+str(j+100)+'.txt') 
	data = np.float32(data)


	N = len(data)
	N = len(data)
	data = torch.from_numpy(data)


	Torsion = np.zeros((N,2))

	def Compute_torsion(U): 
		n = len(U)

		ChainA = U[:,0] 
		ChainB = U[:,1]

		ChainA = ChainA.reshape(n,1) 
		ChainB = ChainB.reshape(n,1)


		out = torch.cat((ChainA,ChainB),1)

		return out


	n = 1
	N1 = int(N/n)
	for i in range(n):
		inputs = data[i*N1:(i+1)*N1,:]

		Torsion[i*N1:(i+1)*N1,:] = Compute_torsion(inputs).detach()

		if(i%1 == 0):
			print('i=',i)


	H, xgrid, ygrid = np.histogram2d(Torsion[:,0],Torsion[:,1],bins = 100)
	
	H = H.transpose()

	np.savetxt('fes-rot'+str(j+100)+'.txt', H, fmt='%.6f')


	fig = plt.figure(figsize=(8,6))
	ax = fig.gca()
	surf = plt.imshow(-0.641866766*np.log(H), cmap = cm.jet, interpolation='nearest', origin='low', extent=[xgrid[0], xgrid[-1], ygrid[0], ygrid[-1]], aspect='auto')
	ax.set_xlabel(r'$\ChainA$',fontsize=18)
	ax.set_ylabel(r'$\ChainB$',fontsize=18)
	plt.xlim((0,360))
	plt.ylim((0,360))
	plt.xlabel("Helix rotation angle (°), chain A")
	plt.ylabel("Helix rotation angle (°), chain B")
	clb = fig.colorbar(surf, shrink=1.0, aspect=10)
	clb.ax.set_title(r'$\Delta$G',fontsize=20)
	plt.savefig('FES_simulation_rot'+str(j+100)+'.pdf',dpi=100)
