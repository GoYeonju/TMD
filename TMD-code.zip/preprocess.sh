#!/bin/csh

set i = 100 
while($i < 101)
	set name = `printf "%i" $i`

	cat test{$name}.gro | grep -e '7ILE     BB   14' -e '8ILE     BB   16' -e '9ILE     BB   18' -e '10LEU     BB   20' -e '30THR     BB   65' -e '31VAL     BB   67' -e '28LEU     BB   60' -e '29ARG     BB   62' | awk '{print $4, $5, $6}' > {$name}A.txt

	cat test{$name}.gro | grep -e '7ILE     BB   93' -e '8ILE     BB   95' -e '9ILE     BB   97' -e '10LEU     BB   99' -e '30THR     BB  144' -e '31VAL     BB  146' -e '28LEU     BB  139' -e '29ARG     BB  141' | awk '{print $4, $5, $6}' > {$name}B.txt

	 grep -A 0 'BB' test{$name}.gro  > coordi{$name}.gro	
	 grep -A 27 '7ILE     BB   14' coordi{$name}.gro | awk '{print $4, $5, $6}' > tempA{$name}.gro	
	 grep -ve '^ *$' tempA{$name}.gro > coordi{$name}A.txt
	 grep -A 27 '7ILE     BB   93' coordi{$name}.gro | awk '{print $4, $5, $6}' > tempB{$name}.gro	
	 grep -ve '^ *$' tempB{$name}.gro > coordi{$name}B.txt
	 rm tempA{$name}.gro
	 rm tempB{$name}.gro

	 grep -A 3 '19PHE     BB   35' coordi{$name}.gro | awk '{print $4, $5, $6}' > temp2A{$name}.gro	
	 grep -ve '^ *$' temp2A{$name}.gro > middle{$name}A.txt
	 grep -A 3 '19PHE     BB  114' coordi{$name}.gro | awk '{print $4, $5, $6}' > temp2B{$name}.gro	
	 grep -ve '^ *$' temp2B{$name}.gro > middle{$name}B.txt
	 rm temp2A{$name}.gro
	 rm temp2B{$name}.gro

        @ i = $i + 1
end
 
