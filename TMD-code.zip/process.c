#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int middlepoint()
{
	int i, j, k;
	FILE *in, *out,*in2,*out2;
	double *x,*y,*z,*xb,*yb,*zb;
	char c;
	char buf[256];

	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "middle%dA.txt", i);
		in = fopen(buf, "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

		x = malloc(N*sizeof(double));
		y = malloc(N*sizeof(double));
		z = malloc(N*sizeof(double));
		xb = malloc(N*sizeof(double));
		yb = malloc(N*sizeof(double));
		zb = malloc(N*sizeof(double));
                
		sprintf(buf, "middle%dA.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "middle%dB.txt", i);         
		in2 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "middle-point%dA.txt", i);   
                out = fopen(buf, "w"); 
		sprintf(buf, "middle-point%dB.txt", i);   
                out2 = fopen(buf, "w"); 
               
		for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
                        fscanf(in2, "%lf%lf%lf\n", &xb[j], &yb[j], &zb[j]);
		}	
                for(j=0; j<N/4; j++){ 
			
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[4*j]+x[4*j+1]+x[4*j+2]+x[4*j+3])/4, (y[4*j]+y[4*j+1]+y[4*j+2]+y[4*j+3])/4, (z[4*j]+z[4*j+1]+z[4*j+2]+z[4*j+3])/4);                                                     
                        fprintf(out2, "%lf\t%lf\t%lf\n",  (xb[4*j]+xb[4*j+1]+xb[4*j+2]+xb[4*j+3])/4, (yb[4*j]+yb[4*j+1]+yb[4*j+2]+yb[4*j+3])/4, (zb[4*j]+zb[4*j+1]+zb[4*j+2]+zb[4*j+3])/4);                                                     
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(out); 
                fclose(out2); 
		} 
	return 0;                                                                                                         
}        

int makeaxisA()
{
	int i, j, k;
	FILE *in, *out;
	double *x,*y,*z;
	char c;
	char buf[256];

	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "%dA.txt", i);
		in = fopen(buf, "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

		x = malloc(N*sizeof(double));
		y = malloc(N*sizeof(double));
		z = malloc(N*sizeof(double));
                
		sprintf(buf, "%dA.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "axis%dA.txt", i);   
                out = fopen(buf, "w"); 
               
		for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
		}	
                for(j=0; j<N/8; j++){ 
			
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[8*j]+x[8*j+1]+x[8*j+2]+x[8*j+3])/4, (y[8*j]+y[8*j+1]+y[8*j+2]+y[8*j+3])/4, (z[8*j]+z[8*j+1]+z[8*j+2]+z[8*j+3])/4);   // (a, b, c) vector                                                  
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[8*j+4]+x[8*j+5]+x[8*j+6]+x[8*j+7])/4, (y[8*j+4]+y[8*j+5]+y[8*j+6]+y[8*j+7])/4, (z[8*j+4]+z[8*j+5]+z[8*j+6]+z[8*j+7])/4);   // (a, b, c) vector                                                  
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(out); 
		} 
	return 0;                                                                                                         
}        

int makeaxisB()
{
	int i, j, k;
	FILE *in, *out;
	double *x,*y,*z;
	char c;
	char buf[256];

	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "%dB.txt", i);
		in = fopen(buf, "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

		x = malloc(N*sizeof(double));
		y = malloc(N*sizeof(double));
		z = malloc(N*sizeof(double));
                
		sprintf(buf, "%dB.txt", i);                                                                              
                in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "axis%dB.txt", i);                                                                                 
                out = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
		}	
                for(j=0; j<N/8; j++){ 
			
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[8*j]+x[8*j+1]+x[8*j+2]+x[8*j+3])/4, (y[8*j]+y[8*j+1]+y[8*j+2]+y[8*j+3])/4, (z[8*j]+z[8*j+1]+z[8*j+2]+z[8*j+3])/4);   // (a, b, c) vector                                                  
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[8*j+4]+x[8*j+5]+x[8*j+6]+x[8*j+7])/4, (y[8*j+4]+y[8*j+5]+y[8*j+6]+y[8*j+7])/4, (z[8*j+4]+z[8*j+5]+z[8*j+6]+z[8*j+7])/4);   // (a, b, c) vector                                                  
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(out); 
		} 
	return 0;                                                                                                         
}        

int extaxisA()                                                                                                                             
{                                                                                                                                      
        int i,j,k;                                                                                                                       
        FILE *in, *out, *out2, *out3;                                                                                                                
        double *x,*y,*z;                                                                                                                  
	char c;
        char buf[256];                                                                                                                 
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "axis%dA.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((c = fgetc(in)) != EOF){
				if(c == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
                x = malloc(N*sizeof(double));
                y = malloc(N*sizeof(double));
                z = malloc(N*sizeof(double));
	                                                                                                          
                sprintf(buf, "axis%dA.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "axis%dA-result.txt", k);                                                                                 
                out = fopen(buf, "w");
 
		sprintf(buf, "axis%dA-point.txt", k);                                                                                
                out2 = fopen(buf, "w");
 
		sprintf(buf, "axis%dA-end.txt", k);                                                                                
                out3 = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
		}	
                for(j=0; j<N/2; j++){ 
			
                        fprintf(out, "%lf\t%lf\t%lf\n",  x[2*j]-x[2*j+1], y[2*j]-y[2*j+1], z[2*j]-z[2*j+1]);                                                     
                        fprintf(out2, "%lf\t%lf\t%lf\n",  x[2*j], y[2*j], z[2*j]);                                                     
                        fprintf(out3, "%lf\t%lf\t%lf\n",  x[2*j+1], y[2*j+1], z[2*j+1]);                                                    
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(out); 
                fclose(out2); 
                fclose(out3); 
		} 
	return 0;                                                                                                         
}        
                
int extaxisB()                                                                                                                             
{                                                                                                                                      
        int i,j,k;                                                                                                                       
        FILE *in, *out, *out2, *out3;                                                                                                                
        double *x,*y,*z;                                                                                                                  
	char c;
        char buf[256];                                                                                                                 
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "axis%dB.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((c = fgetc(in)) != EOF){
				if(c == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
                x = malloc(N*sizeof(double));
                y = malloc(N*sizeof(double));
                z = malloc(N*sizeof(double));
	                                                                                                          
                sprintf(buf, "axis%dB.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "axis%dB-result.txt", k);                                                                               
                out = fopen(buf, "w"); 
		sprintf(buf, "axis%dB-point.txt", k);                                                                          
                out2 = fopen(buf, "w"); 
		sprintf(buf, "axis%dB-end.txt", k);                                                                            
                out3 = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
		}	
                for(j=0; j<N/2; j++){ 
			
                        fprintf(out, "%lf\t%lf\t%lf\n",  x[2*j]-x[2*j+1], y[2*j]-y[2*j+1], z[2*j]-z[2*j+1]);                                                
                        fprintf(out2, "%lf\t%lf\t%lf\n",  x[2*j], y[2*j], z[2*j]);                                                 
                        fprintf(out3, "%lf\t%lf\t%lf\n",  x[2*j+1], y[2*j+1], z[2*j+1]);                                              
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(out); 
                fclose(out2); 
                fclose(out3); 
		} 
	return 0;                                                                                                         
}        

int outvectest()
{
	int i, j, k;
	FILE *in, *in2, *out, *out2;
	double a, b, c, aq, bq, cq;

	char C;
	char buf[256];
	
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "axis%dA-result.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((C = fgetc(in)) != EOF){
				if(C == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
	                                                                                                          
                sprintf(buf, "axis%dA-result.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                sprintf(buf, "axis%dB-result.txt", k);                                                                              
                in2 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "outvecA-test%d.txt", k);                                                                                 
                out = fopen(buf, "w"); 
		sprintf(buf, "outvecB-test%d.txt", k);    
                out2 = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a, &b, &c);
                        fscanf(in2, "%lf%lf%lf\n", &aq, &bq, &cq);
                        fprintf(out, "%lf\t%lf\t%lf\n",  (b*cq-bq*c), (c*aq-a*cq), (a*bq-aq*b));                                                 
                        fprintf(out2, "%lf\t%lf\t%lf\n",  (bq*c-b*cq), (a*cq-c*aq), (aq*b-a*bq));                                               
		}                                                                                                                    
                fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(out); 
                fclose(out2); 
		} 
	return 0;                                                                                                         
}        
	 
                
int ca()
{
	int i,j,k;
	double l;
	FILE *in, *out, *out2, *out3,*out4,*in2, *in3, *in4, *in5;
	double *t, *tq, *deld, *dele, *delf, *pp, *qq, *rr, *tha0, *tha2, *sum,*tha,*a,*b,*c,*aq,*bq,*cq,*x0,*y0,*z0, *x1,*y1,*z1,*x2,*y2,*z2,*p,*q,*r, *x0q, *y0q, *z0q;
	char C;
	char buf[1000];
	
	for(i=100; i<101; i++){
		double count[2000] ={0};
		int N=0;
		sprintf(buf, "axis%dA-result.txt", i);
		in = fopen(buf, "r");
			while((C=fgetc(in)) != EOF){
				if(C == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);
                
		t = malloc(N*sizeof(double));
                tq = malloc(N*sizeof(double));
		deld = malloc(N*sizeof(double));
                dele = malloc(N*sizeof(double));
                delf = malloc(N*sizeof(double));
                x0 = malloc(N*sizeof(double));
                y0 = malloc(N*sizeof(double));
                z0 = malloc(N*sizeof(double));
                x0q = malloc(N*sizeof(double));
                y0q = malloc(N*sizeof(double));
                z0q = malloc(N*sizeof(double));
		a = malloc(N*sizeof(double));
                b = malloc(N*sizeof(double));
                c = malloc(N*sizeof(double));
		aq = malloc(N*sizeof(double));
                bq = malloc(N*sizeof(double));
                cq = malloc(N*sizeof(double));
                p = malloc(N*sizeof(double));
                q = malloc(N*sizeof(double));
                r = malloc(N*sizeof(double));
                tha = malloc(N*sizeof(double));
 
		sprintf(buf, "axis%dA-result.txt", i);	
		in = fopen(buf, "r");
		sprintf(buf, "axis%dA-point.txt", i);	
		in2 = fopen(buf, "r");
		sprintf(buf, "outvecA-test%d.txt", i);	
		in3 = fopen(buf, "r");
		sprintf(buf, "axis%dB-result.txt", i);	
		in4 = fopen(buf, "r");
		sprintf(buf, "axis%dB-point.txt", i);	
		in5 = fopen(buf, "r");
		sprintf(buf, "CA%d.txt", i);		// crossing angle
		out = fopen(buf, "w");
		sprintf(buf, "CA-FES%d.txt", i);		
		out2 = fopen(buf, "w");
		
		for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a[j], &b[j], &c[j]);
                        fscanf(in2, "%lf%lf%lf\n", &x0[j], &y0[j], &z0[j]);
                        fscanf(in3, "%lf%lf%lf\n", &p[j], &q[j], &r[j]);
                        fscanf(in4, "%lf%lf%lf\n", &aq[j], &bq[j], &cq[j]);
                        fscanf(in5, "%lf%lf%lf\n", &x0q[j], &y0q[j], &z0q[j]);
                }
		fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in4);                                                                                                            
                fclose(in5);                                                                                                            
		for(j=0; j<N; j++){ 
                
		        t[j]=((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*(aq[j]*(x0q[j]-x0[j])+bq[j]*(y0q[j]-y0[j])+cq[j]*(z0q[j]-z0[j])-(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j])*(a[j]*(x0q[j]-x0[j])+b[j]*(y0q[j]-y0[j])+c[j]*(z0q[j]-z0[j]))))/((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*(a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])-(a[j]*a[j]+b[j]*b[j]+c[j]*c[j])*(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]));
			tq[j]=((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*t[j]-(aq[j]*(x0q[j]-x0[j])+bq[j]*(y0q[j]-y0[j])+cq[j]*(z0q[j]-z0[j])))/(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]);
			deld[j]=x0q[j]-x0[j]+aq[j]*tq[j]-a[j]*t[j];
			dele[j]=y0q[j]-y0[j]+bq[j]*tq[j]-b[j]*t[j];
			delf[j]=z0q[j]-z0[j]+cq[j]*tq[j]-c[j]*t[j];
			tha[j]=acos((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])/sqrt((a[j]*a[j]+b[j]*b[j]+c[j]*c[j])*(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j])));
			if((deld[j]*p[j]+dele[j]*q[j]+delf[j]*r[j])>0){
				tha[j] = -tha[j];  //left-handed
			}
			else{
				tha[j] = tha[j];  //right-handed
			}
			tha[j]=180*tha[j]/M_PI;
			fprintf(out, "%lf\n",  tha[j]);                                                      
  		}
                fclose(out); 
		
		for(j=0; j<N; j++){ 
			for(l=-90, k=0; l<110, k<2000; l=l+0.1, k++){
					if((tha[j]>=l)&&(tha[j]<l+0.1)){
						count[k]++;
					}
				}  		
		}
		int sum=0;
		for(k=0; k<2000; k++){
			fprintf(out2, "%lf\t%lf\n", (k*0.1-90), -log(count[k]/N));
			sum=sum+count[k];
		 
		} 		
		printf("sum %d\n", sum);
                fclose(out2); 
	} 
	return 0;                                                                                                         
}        
		
int outvecA()
{
	int i, j, k;
	FILE *in, *in2, *in3,*in4,*in5,*in6, *out, *out2;
	double *ca,*mx,*my,*mz,*a, *b, *c, *aq, *bq, *cq,*p,*q,*r,*t,*tq,*x0,*y0,*z0,*x0q,*y0q,*z0q;

	char C;
	char buf[256];
	
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "middle-point%dA.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((C = fgetc(in)) != EOF){
				if(C == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
		a = malloc(N*sizeof(double));
                b = malloc(N*sizeof(double));
                c = malloc(N*sizeof(double));
                mx = malloc(N*sizeof(double));
                my = malloc(N*sizeof(double));
                mz = malloc(N*sizeof(double));
                x0 = malloc(N*sizeof(double));
                y0 = malloc(N*sizeof(double));
                z0 = malloc(N*sizeof(double));
		aq = malloc(N*sizeof(double));
                bq = malloc(N*sizeof(double));
                cq = malloc(N*sizeof(double));
                x0q = malloc(N*sizeof(double));
                y0q = malloc(N*sizeof(double));
                z0q = malloc(N*sizeof(double));
                p = malloc(N*sizeof(double));
                q = malloc(N*sizeof(double));
                r = malloc(N*sizeof(double));
		t = malloc(N*sizeof(double));
                tq = malloc(N*sizeof(double));
                ca = malloc(N*sizeof(double));
	                                                                                                          
                sprintf(buf, "axis%dA-result.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                sprintf(buf, "axis%dB-result.txt", k);                                                                              
                in2 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "middle-point%dA.txt", k);	
		in3 = fopen(buf, "r");
		sprintf(buf, "axis%dB-point.txt", k);	
		in4 = fopen(buf, "r");
		sprintf(buf, "axis%dA-point.txt", k);	
		in5 = fopen(buf, "r");
		sprintf(buf, "CA%d.txt", k);	
		in6 = fopen(buf, "r");
		sprintf(buf, "outvecA%d.txt", k);                                                                                 
                out = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a[j], &b[j], &c[j]);
                        fscanf(in2, "%lf%lf%lf\n", &aq[j], &bq[j], &cq[j]);
                        fscanf(in3, "%lf%lf%lf\n", &mx[j], &my[j], &mz[j]);
                        fscanf(in4, "%lf%lf%lf\n", &x0q[j], &y0q[j], &z0q[j]);
                        fscanf(in5, "%lf%lf%lf\n", &x0[j], &y0[j], &z0[j]);
                        fscanf(in6, "%lf\n", &ca[j]);
                }
		fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in4);                                                                                                            
                fclose(in5);                                                                                                            
                fclose(in6);                                                                                                            
                for(j=0; j<N; j++){ 
	                if(ca[j]<14.4&&ca[j]>-14.4){ 
			t[j]= ((mx[j]-x0q[j])*aq[j]+(my[j]-y0q[j])*bq[j]+(mz[j]-z0q[j])*cq[j])/(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]);
			p[j]=x0q[j]-mx[j]+aq[j]*t[j];	
			q[j]=y0q[j]-my[j]+bq[j]*t[j];	
			r[j]=z0q[j]-mz[j]+cq[j]*t[j];	
			}
			else{	
                        t[j]= ((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*(aq[j]*(x0q[j]-x0[j])+bq[j]*(y0q[j]-y0[j])+cq[j]*(z0q[j]-z0[j]))-(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j])*(a[j]*(x0q[j]-x0[j])+b[j]*(y0q[j]-y0[j])+c[j]*(z0q[j]-z0[j])))/((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*(a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])-(a[j]*a[j]+b[j]*b[j]+c[j]*c[j])*(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]));
			tq[j]=((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*t[j]-(aq[j]*(x0q[j]-x0[j])+bq[j]*(y0q[j]-y0[j])+cq[j]*(z0q[j]-z0[j])))/(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]);
			p[j]=x0q[j]-x0[j]+aq[j]*tq[j]-a[j]*t[j];	
			q[j]=y0q[j]-y0[j]+bq[j]*tq[j]-b[j]*t[j];	
			r[j]=z0q[j]-z0[j]+cq[j]*tq[j]-c[j]*t[j];	
                        }
			fprintf(out, "%lf\t%lf\t%lf\n",  p[j],q[j],r[j]);                                                       
                }                                                                                                                     
                fclose(out); 
		} 
		return 0;                                                                                                         
}        
	 
int outvecB()
{
	int i, j, k;
	FILE *in, *in2, *in3,*in4,*in5,*in6, *out, *out2;
	double *ca,*mx,*my,*mz,*a, *b, *c, *aq, *bq, *cq,*p,*q,*r,*t,*tq,*x0,*y0,*z0,*x0q,*y0q,*z0q;

	char C;
	char buf[256];
	
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "middle-point%dB.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((C = fgetc(in)) != EOF){
				if(C == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
		a = malloc(N*sizeof(double));
                b = malloc(N*sizeof(double));
                c = malloc(N*sizeof(double));
                mx = malloc(N*sizeof(double));
                my = malloc(N*sizeof(double));
                mz = malloc(N*sizeof(double));
                x0 = malloc(N*sizeof(double));
                y0 = malloc(N*sizeof(double));
                z0 = malloc(N*sizeof(double));
		aq = malloc(N*sizeof(double));
                bq = malloc(N*sizeof(double));
                cq = malloc(N*sizeof(double));
                x0q = malloc(N*sizeof(double));
                y0q = malloc(N*sizeof(double));
                z0q = malloc(N*sizeof(double));
                p = malloc(N*sizeof(double));
                q = malloc(N*sizeof(double));
                r = malloc(N*sizeof(double));
		t = malloc(N*sizeof(double));
                tq = malloc(N*sizeof(double));
                ca = malloc(N*sizeof(double));
	                                                                                                          
                sprintf(buf, "axis%dB-result.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                sprintf(buf, "axis%dA-result.txt", k);                                                                              
                in2 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "middle-point%dB.txt", k);	
		in3 = fopen(buf, "r");
		sprintf(buf, "axis%dA-point.txt", k);	
		in4 = fopen(buf, "r");
		sprintf(buf, "axis%dB-point.txt", k);	
		in5 = fopen(buf, "r");
		sprintf(buf, "CA%d.txt", k);	
		in6 = fopen(buf, "r");
		sprintf(buf, "outvecB%d.txt", k);                                                                                 
                out = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a[j], &b[j], &c[j]);
                        fscanf(in2, "%lf%lf%lf\n", &aq[j], &bq[j], &cq[j]);
                        fscanf(in3, "%lf%lf%lf\n", &mx[j], &my[j], &mz[j]);
                        fscanf(in4, "%lf%lf%lf\n", &x0q[j], &y0q[j], &z0q[j]);
                        fscanf(in5, "%lf%lf%lf\n", &x0[j], &y0[j], &z0[j]);
                        fscanf(in6, "%lf\n", &ca[j]);
                }
		fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in4);                                                                                                            
                fclose(in5);                                                                                                            
                fclose(in6);                                                                                                            
                for(j=0; j<N; j++){ 
	                if(ca[j]<14.4&&ca[j]>-14.4){ 
			t[j]= ((mx[j]-x0q[j])*aq[j]+(my[j]-y0q[j])*bq[j]+(mz[j]-z0q[j])*cq[j])/(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]);
			p[j]=x0q[j]-mx[j]+aq[j]*t[j];	
			q[j]=y0q[j]-my[j]+bq[j]*t[j];	
			r[j]=z0q[j]-mz[j]+cq[j]*t[j];	
			}
			else{	
                        t[j]= ((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*(aq[j]*(x0q[j]-x0[j])+bq[j]*(y0q[j]-y0[j])+cq[j]*(z0q[j]-z0[j]))-(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j])*(a[j]*(x0q[j]-x0[j])+b[j]*(y0q[j]-y0[j])+c[j]*(z0q[j]-z0[j])))/((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*(a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])-(a[j]*a[j]+b[j]*b[j]+c[j]*c[j])*(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]));
			tq[j]=((a[j]*aq[j]+b[j]*bq[j]+c[j]*cq[j])*t[j]-(aq[j]*(x0q[j]-x0[j])+bq[j]*(y0q[j]-y0[j])+cq[j]*(z0q[j]-z0[j])))/(aq[j]*aq[j]+bq[j]*bq[j]+cq[j]*cq[j]);
			p[j]=x0q[j]-x0[j]+aq[j]*tq[j]-a[j]*t[j];	
			q[j]=y0q[j]-y0[j]+bq[j]*tq[j]-b[j]*t[j];	
			r[j]=z0q[j]-z0[j]+cq[j]*tq[j]-c[j]*t[j];	
                        }
			fprintf(out, "%lf\t%lf\t%lf\n",  p[j],q[j],r[j]);                                                     
                }                                                                                                                     
                fclose(out); 
		} 
		return 0;                                                                                                         
}        
	 
int outvecrevise()
{
	int i, j, k;
	FILE *in, *in2, *out, *out2;
	double a, b, c, aq, bq, cq;

	char C;
	char buf[256];
	
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "outvecA%d.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((C = fgetc(in)) != EOF){
				if(C == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
	                                                                                                          
                sprintf(buf, "outvecA%d.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                sprintf(buf, "outvecB%d.txt", k);                                                                              
                in2 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "outvecA-revise%d.txt", k);                                                                                 
                out = fopen(buf, "w"); 
		sprintf(buf, "outvecB-revise%d.txt", k);    
                out2 = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a, &b, &c);
                        fscanf(in2, "%lf%lf%lf\n", &aq, &bq, &cq);
                	for(i=0; i<28; i++){ 
                        fprintf(out, "%lf\t%lf\t%lf\n",  a,b,c);                                                      
                        fprintf(out2, "%lf\t%lf\t%lf\n",  aq,bq,cq);                                                   
                	} 
		}                                                                                                                    
                fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(out); 
                fclose(out2); 
		} 
	return 0;                                                                                                         
}        
	 
int helixAterm()
{
	int i, j, k;
	FILE *in, *out, *out2;
	double *x,*y,*z;
	char c;
	char buf[256];

	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "coordi%dA.txt", i);
		in = fopen(buf, "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

		x = malloc(N*sizeof(double));
		y = malloc(N*sizeof(double));
		z = malloc(N*sizeof(double));
                
		sprintf(buf, "coordi%dA.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "helixA-term-axis%d.txt", i);   
                out = fopen(buf, "w"); 
		sprintf(buf, "helixA-term-point%d.txt", i);   
                out2 = fopen(buf, "w"); 
               
		for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
		}	
                for(j=0; j<N/28; j++){ 
			for(k=0; k<4;k++){		
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j]+x[28*j+1]+x[28*j+2]+x[28*j+3])/4-(x[28*j+4]+x[28*j+5]+x[28*j+6]+x[28*j+7])/4, (y[28*j]+y[28*j+1]+y[28*j+2]+y[28*j+3])/4-(y[28*j+4]+y[28*j+5]+y[28*j+6]+y[28*j+7])/4, (z[28*j]+z[28*j+1]+z[28*j+2]+z[28*j+3])/4-(z[28*j+4]+z[28*j+5]+z[28*j+6]+z[28*j+7])/4);                                                    
                        }
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+4]+x[28*j+5]+x[28*j+6]+x[28*j+7])/4-(x[28*j+8]+x[28*j+9]+x[28*j+10]+x[28*j+11])/4, (y[28*j+4]+y[28*j+5]+y[28*j+6]+y[28*j+7])/4-(y[28*j+8]+y[28*j+9]+y[28*j+10]+y[28*j+11])/4, (z[28*j+4]+z[28*j+5]+z[28*j+6]+z[28*j+7])/4-(z[28*j+8]+z[28*j+9]+z[28*j+10]+z[28*j+11])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+8]+x[28*j+9]+x[28*j+10]+x[28*j+11])/4-(x[28*j+12]+x[28*j+13]+x[28*j+14]+x[28*j+15])/4, (y[28*j+8]+y[28*j+9]+y[28*j+10]+y[28*j+11])/4-(y[28*j+12]+y[28*j+13]+y[28*j+14]+y[28*j+15])/4, (z[28*j+8]+z[28*j+9]+z[28*j+10]+z[28*j+11])/4-(z[28*j+12]+z[28*j+13]+z[28*j+14]+z[28*j+15])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+12]+x[28*j+13]+x[28*j+14]+x[28*j+15])/4-(x[28*j+16]+x[28*j+17]+x[28*j+18]+x[28*j+19])/4, (y[28*j+12]+y[28*j+13]+y[28*j+14]+y[28*j+15])/4-(y[28*j+16]+y[28*j+17]+y[28*j+18]+y[28*j+19])/4, (z[28*j+12]+z[28*j+13]+z[28*j+14]+z[28*j+15])/4-(z[28*j+16]+z[28*j+17]+z[28*j+18]+z[28*j+19])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+16]+x[28*j+17]+x[28*j+18]+x[28*j+19])/4-(x[28*j+20]+x[28*j+21]+x[28*j+22]+x[28*j+23])/4, (y[28*j+16]+y[28*j+17]+y[28*j+18]+y[28*j+19])/4-(y[28*j+20]+y[28*j+21]+y[28*j+22]+y[28*j+23])/4, (z[28*j+16]+z[28*j+17]+z[28*j+18]+z[28*j+19])/4-(z[28*j+20]+z[28*j+21]+z[28*j+22]+z[28*j+23])/4);
			}                                                  
			for(k=0;k<8;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+20]+x[28*j+21]+x[28*j+22]+x[28*j+23])/4-(x[28*j+24]+x[28*j+25]+x[28*j+26]+x[28*j+27])/4, (y[28*j+20]+y[28*j+21]+y[28*j+22]+y[28*j+23])/4-(y[28*j+24]+y[28*j+25]+y[28*j+26]+y[28*j+27])/4, (z[28*j+20]+z[28*j+21]+z[28*j+22]+z[28*j+23])/4-(z[28*j+24]+z[28*j+25]+z[28*j+26]+z[28*j+27])/4);
			}                                                  
			for(k=0; k<4;k++){		
                       		 fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j]+x[28*j+1]+x[28*j+2]+x[28*j+3])/4, (y[28*j]+y[28*j+1]+y[28*j+2]+y[28*j+3])/4, (z[28*j]+z[28*j+1]+z[28*j+2]+z[28*j+3])/4);                                                   
                        }
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+4]+x[28*j+5]+x[28*j+6]+x[28*j+7])/4, (y[28*j+4]+y[28*j+5]+y[28*j+6]+y[28*j+7])/4, (z[28*j+4]+z[28*j+5]+z[28*j+6]+z[28*j+7])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+8]+x[28*j+9]+x[28*j+10]+x[28*j+11])/4, (y[28*j+8]+y[28*j+9]+y[28*j+10]+y[28*j+11])/4, (z[28*j+8]+z[28*j+9]+z[28*j+10]+z[28*j+11])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+12]+x[28*j+13]+x[28*j+14]+x[28*j+15])/4, (y[28*j+12]+y[28*j+13]+y[28*j+14]+y[28*j+15])/4, (z[28*j+12]+z[28*j+13]+z[28*j+14]+z[28*j+15])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+16]+x[28*j+17]+x[28*j+18]+x[28*j+19])/4, (y[28*j+16]+y[28*j+17]+y[28*j+18]+y[28*j+19])/4, (z[28*j+16]+z[28*j+17]+z[28*j+18]+z[28*j+19])/4);
			}                                                  
			for(k=0;k<8;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+20]+x[28*j+21]+x[28*j+22]+x[28*j+23])/4, (y[28*j+20]+y[28*j+21]+y[28*j+22]+y[28*j+23])/4, (z[28*j+20]+z[28*j+21]+z[28*j+22]+z[28*j+23])/4);
			}                                                  
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(out); 
                fclose(out2); 
		} 
	return 0;                                                                                                         
}        

int helixBterm()
{
	int i, j, k;
	FILE *in, *out, *out2;
	double *x,*y,*z;
	char c;
	char buf[256];

	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "coordi%dB.txt", i);
		in = fopen(buf, "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

		x = malloc(N*sizeof(double));
		y = malloc(N*sizeof(double));
		z = malloc(N*sizeof(double));
                
		sprintf(buf, "coordi%dB.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "helixB-term-axis%d.txt", i);   
                out = fopen(buf, "w"); 
		sprintf(buf, "helixB-term-point%d.txt", i);   
                out2 = fopen(buf, "w"); 
               
		for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
		}	
                for(j=0; j<N/28; j++){ 
			for(k=0; k<4;k++){		
                        fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j]+x[28*j+1]+x[28*j+2]+x[28*j+3])/4-(x[28*j+4]+x[28*j+5]+x[28*j+6]+x[28*j+7])/4, (y[28*j]+y[28*j+1]+y[28*j+2]+y[28*j+3])/4-(y[28*j+4]+y[28*j+5]+y[28*j+6]+y[28*j+7])/4, (z[28*j]+z[28*j+1]+z[28*j+2]+z[28*j+3])/4-(z[28*j+4]+z[28*j+5]+z[28*j+6]+z[28*j+7])/4);                                                     
                        }
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+4]+x[28*j+5]+x[28*j+6]+x[28*j+7])/4-(x[28*j+8]+x[28*j+9]+x[28*j+10]+x[28*j+11])/4, (y[28*j+4]+y[28*j+5]+y[28*j+6]+y[28*j+7])/4-(y[28*j+8]+y[28*j+9]+y[28*j+10]+y[28*j+11])/4, (z[28*j+4]+z[28*j+5]+z[28*j+6]+z[28*j+7])/4-(z[28*j+8]+z[28*j+9]+z[28*j+10]+z[28*j+11])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+8]+x[28*j+9]+x[28*j+10]+x[28*j+11])/4-(x[28*j+12]+x[28*j+13]+x[28*j+14]+x[28*j+15])/4, (y[28*j+8]+y[28*j+9]+y[28*j+10]+y[28*j+11])/4-(y[28*j+12]+y[28*j+13]+y[28*j+14]+y[28*j+15])/4, (z[28*j+8]+z[28*j+9]+z[28*j+10]+z[28*j+11])/4-(z[28*j+12]+z[28*j+13]+z[28*j+14]+z[28*j+15])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+12]+x[28*j+13]+x[28*j+14]+x[28*j+15])/4-(x[28*j+16]+x[28*j+17]+x[28*j+18]+x[28*j+19])/4, (y[28*j+12]+y[28*j+13]+y[28*j+14]+y[28*j+15])/4-(y[28*j+16]+y[28*j+17]+y[28*j+18]+y[28*j+19])/4, (z[28*j+12]+z[28*j+13]+z[28*j+14]+z[28*j+15])/4-(z[28*j+16]+z[28*j+17]+z[28*j+18]+z[28*j+19])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+16]+x[28*j+17]+x[28*j+18]+x[28*j+19])/4-(x[28*j+20]+x[28*j+21]+x[28*j+22]+x[28*j+23])/4, (y[28*j+16]+y[28*j+17]+y[28*j+18]+y[28*j+19])/4-(y[28*j+20]+y[28*j+21]+y[28*j+22]+y[28*j+23])/4, (z[28*j+16]+z[28*j+17]+z[28*j+18]+z[28*j+19])/4-(z[28*j+20]+z[28*j+21]+z[28*j+22]+z[28*j+23])/4);
			}                                                  
			for(k=0;k<8;k++){
				fprintf(out, "%lf\t%lf\t%lf\n",  (x[28*j+20]+x[28*j+21]+x[28*j+22]+x[28*j+23])/4-(x[28*j+24]+x[28*j+25]+x[28*j+26]+x[28*j+27])/4, (y[28*j+20]+y[28*j+21]+y[28*j+22]+y[28*j+23])/4-(y[28*j+24]+y[28*j+25]+y[28*j+26]+y[28*j+27])/4, (z[28*j+20]+z[28*j+21]+z[28*j+22]+z[28*j+23])/4-(z[28*j+24]+z[28*j+25]+z[28*j+26]+z[28*j+27])/4);
			}                                                  
			for(k=0; k<4;k++){		
                       		 fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j]+x[28*j+1]+x[28*j+2]+x[28*j+3])/4, (y[28*j]+y[28*j+1]+y[28*j+2]+y[28*j+3])/4, (z[28*j]+z[28*j+1]+z[28*j+2]+z[28*j+3])/4);                                                     
                        }
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+4]+x[28*j+5]+x[28*j+6]+x[28*j+7])/4, (y[28*j+4]+y[28*j+5]+y[28*j+6]+y[28*j+7])/4, (z[28*j+4]+z[28*j+5]+z[28*j+6]+z[28*j+7])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+8]+x[28*j+9]+x[28*j+10]+x[28*j+11])/4, (y[28*j+8]+y[28*j+9]+y[28*j+10]+y[28*j+11])/4, (z[28*j+8]+z[28*j+9]+z[28*j+10]+z[28*j+11])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+12]+x[28*j+13]+x[28*j+14]+x[28*j+15])/4, (y[28*j+12]+y[28*j+13]+y[28*j+14]+y[28*j+15])/4, (z[28*j+12]+z[28*j+13]+z[28*j+14]+z[28*j+15])/4);
			}                                                  
			for(k=0;k<4;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+16]+x[28*j+17]+x[28*j+18]+x[28*j+19])/4, (y[28*j+16]+y[28*j+17]+y[28*j+18]+y[28*j+19])/4, (z[28*j+16]+z[28*j+17]+z[28*j+18]+z[28*j+19])/4);
			}                                                  
			for(k=0;k<8;k++){
				fprintf(out2, "%lf\t%lf\t%lf\n",  (x[28*j+20]+x[28*j+21]+x[28*j+22]+x[28*j+23])/4, (y[28*j+20]+y[28*j+21]+y[28*j+22]+y[28*j+23])/4, (z[28*j+20]+z[28*j+21]+z[28*j+22]+z[28*j+23])/4);
			}                                                  
                }                                                                                                                     
                fclose(in);                                                                                                            
                fclose(out); 
                fclose(out2); 
		} 
	return 0;                                                                                                         
}        

int outvecnew()
{
	int i, j, k;
	FILE *out3,*out4,*in, *in2, *out, *out2,*in3,*in4;
	double *a,*b,*c,*ma,*mb,*thaA,*thaB,*x,*y,*z,*xb,*yb,*zb,*p,*q,*r,*pb,*qb,*rb,*h1a,*h1b,*h1c,*h2a,*h2b,*h2c;

	char C;
	char buf[1000];
	
		for(k=100; k<101; k++){                                                                                                                       
  		int N = 0;
                sprintf(buf, "helixA-term-axis%d.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                	
			while((C = fgetc(in)) != EOF){
				if(C == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);  
                
		h1a = malloc(N*sizeof(double));
                h1b = malloc(N*sizeof(double));
                h1c = malloc(N*sizeof(double));
                h2a = malloc(N*sizeof(double));
                h2b = malloc(N*sizeof(double));
                h2c = malloc(N*sizeof(double));
                x = malloc(N*sizeof(double));
                y = malloc(N*sizeof(double));
                z = malloc(N*sizeof(double));
                xb = malloc(N*sizeof(double));
                yb = malloc(N*sizeof(double));
                zb = malloc(N*sizeof(double));
                p = malloc(N*sizeof(double));
                q = malloc(N*sizeof(double));
                r = malloc(N*sizeof(double));
                pb = malloc(N*sizeof(double));
                qb = malloc(N*sizeof(double));
                rb = malloc(N*sizeof(double));
                ma = malloc(N*sizeof(double));
                mb = malloc(N*sizeof(double));
                a = malloc(N*sizeof(double));
                b = malloc(N*sizeof(double));
                c = malloc(N*sizeof(double));
	                                                                                                          
                sprintf(buf, "helixA-term-axis%d.txt", k);                                                                              
                in = fopen(buf, "r");                                                                                                  
                sprintf(buf, "helixB-term-axis%d.txt", k);                                                                              
                in2 = fopen(buf, "r");                                                                                                  
                sprintf(buf, "outvecA-revise%d.txt", k);                                                                              
                in3 = fopen(buf, "r");                                                                                                  
                sprintf(buf, "outvecB-revise%d.txt", k);                                                                              
                in4 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "outvecA-new%d.txt", k);                                                                                 
                out = fopen(buf, "w"); 
		sprintf(buf, "outvecB-new%d.txt", k);    
                out2 = fopen(buf, "w"); 
		sprintf(buf, "testA%d.txt", k);                                                                                 
                out3 = fopen(buf, "w"); 
                
		for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &x[j], &y[j], &z[j]);
                        fscanf(in2, "%lf%lf%lf\n", &xb[j], &yb[j], &zb[j]);
                        fscanf(in3, "%lf%lf%lf\n", &p[j], &q[j], &r[j]);
                        fscanf(in4, "%lf%lf%lf\n", &pb[j], &qb[j], &rb[j]);
		}
		fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in4);                                                                                                            
                for(j=0; j<N; j++){
			ma[j]=(p[j]*x[j]+q[j]*y[j]+r[j]*z[j])/(x[j]*x[j]+y[j]*y[j]+z[j]*z[j]);
			h1a[j] = p[j] - ma[j]*x[j];
			h1b[j] = q[j] - ma[j]*y[j];
			h1c[j] = r[j] - ma[j]*z[j];
			mb[j]=(pb[j]*xb[j]+qb[j]*yb[j]+rb[j]*zb[j])/(xb[j]*xb[j]+yb[j]*yb[j]+zb[j]*zb[j]);
			h2a[j] = pb[j] - mb[j]*xb[j];
			h2b[j] = qb[j] - mb[j]*yb[j];
			h2c[j] = rb[j] - mb[j]*zb[j];

			a[j] = h1a[j]*x[j] + h1b[j]*y[j] + h1c[j]*z[j];
 
                        fprintf(out, "%lf\t%lf\t%lf\n",  h1a[j],h1b[j],h1c[j]);                                                  
                        fprintf(out2, "%lf\t%lf\t%lf\n",  h2a[j],h2b[j],h2c[j]);                                                 
                        fprintf(out3, "%lf\n",  a[j]);                                                 
                }                                                                                                                     
                fclose(out); 
                fclose(out2); 
                fclose(out3); 
		} 
	return 0;                                                                                                         
}        
	 
int deldistance()
{
	int i,j,k, sum=0;
	double l;
	FILE *in, *out, *out2, *in2, *in3, *in4, *in5;
	double  *delD,*x0,*y0, *z0, *x0q, *y0q, *z0q, *xe, *ye, *ze, *xeq, *yeq, *zeq;
	char C;
	char buf[1000];
	
	for(i=100; i<101; i++){
		double count[600] = {0};
		int N=0;
		sprintf(buf, "axis%dA-point.txt", i);
		in = fopen(buf, "r");
			while((C=fgetc(in)) != EOF){
				if(C == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);
                
                x0 = malloc(N*sizeof(double));
                y0 = malloc(N*sizeof(double));
                z0 = malloc(N*sizeof(double));
                x0q = malloc(N*sizeof(double));
                y0q = malloc(N*sizeof(double));
                z0q = malloc(N*sizeof(double));
                xe = malloc(N*sizeof(double));
                ye = malloc(N*sizeof(double));
                ze = malloc(N*sizeof(double));
                xeq = malloc(N*sizeof(double));
                yeq = malloc(N*sizeof(double));
                zeq = malloc(N*sizeof(double));
                delD = malloc(N*sizeof(double));
 
		sprintf(buf, "axis%dA-point.txt", i);	
		in = fopen(buf, "r");
		sprintf(buf, "axis%dA-end.txt", i);	
		in2 = fopen(buf, "r");
		sprintf(buf, "axis%dB-point.txt", i);	
		in3 = fopen(buf, "r");
		sprintf(buf, "axis%dB-end.txt", i);	
		in4 = fopen(buf, "r");
		sprintf(buf, "deldist%d.txt", i);		
		out = fopen(buf, "w");
		sprintf(buf, "delD-FES%d.txt", i);		
		out2 = fopen(buf, "w");
		
		for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &x0[j], &y0[j], &z0[j]);
                        fscanf(in2, "%lf%lf%lf\n", &xe[j], &ye[j], &ze[j]);
                        fscanf(in3, "%lf%lf%lf\n", &x0q[j], &y0q[j], &z0q[j]);
                        fscanf(in4, "%lf%lf%lf\n", &xeq[j], &yeq[j], &zeq[j]);
                }
                fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in4);                                                                                                            
		
		for(j=0; j<N; j++){ 

			delD[j]=sqrt((x0[j]-x0q[j])*(x0[j]-x0q[j])+(y0[j]-y0q[j])*(y0[j]-y0q[j])+(z0[j]-z0q[j])*(z0[j]-z0q[j]))-sqrt((xe[j]-xeq[j])*(xe[j]-xeq[j])+(ye[j]-yeq[j])*(ye[j]-yeq[j])+(ze[j]-zeq[j])*(ze[j]-zeq[j]));  // dNter-dCter
	
			fprintf(out, "%lf\n",  delD[j]); // unit: nm                                                     
		}
                fclose(out); 
		for(j=0; j<N; j++){ 
			for(l=-3, k=0; l<3, k<600; l=l+0.01, k++){
					if((delD[j]>=l)&&(delD[j]<l+0.01)){
						count[k]++;
					}
				}  		
		}
		int sum=0;
		for(k=0; k<600; k++){
			fprintf(out2, "%lf\t%lf\n", (k*0.01-3), -log(count[k]/N));
			sum=sum+count[k];
		 
		} 		
		printf("sum %d\n", sum);
                fclose(out2); 
	} 
	return 0;                                                                                                         
}        
		
int rotArevise()
{
	int i,j,k;
	FILE *out6,*out5,*in9,*in, *out, *in2, *in3, *in4,*in5, *in6, *in7, *in8, *out1, *out2, *out3, *out4;
	double *m,*pk,*qk,*rk,*hp1, *hp2, *hp3, *h1, *h2, *h3, *t, *tq, *deld, *dele, *delf, *pp, *qq, *rr, *tha0, *tha2, *sum,*tha,*a,*b,*c,*aq,*bq,*cq,*x0,*y0,*z0, *x1,*y1,*z1,*x2,*y2,*z2,*p,*q,*r, *x0q, *y0q, *z0q;
	char C;
	char buf[1000];
	int NC=28;
	
	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "coordi%dA.txt", i);
		in = fopen(buf, "r");
			while((C=fgetc(in)) != EOF){
				if(C == '\n'){
					N++;
				}
			}
		N = N/NC;
		printf("%d\n", N);
		fclose(in);
                
		t = malloc(N*sizeof(double));
                tq = malloc(N*sizeof(double));
		deld = malloc(N*sizeof(double));
                dele = malloc(N*sizeof(double));
                delf = malloc(N*sizeof(double));
		a = malloc(N*sizeof(double));
                b = malloc(N*sizeof(double));
                c = malloc(N*sizeof(double));
                x0 = malloc(N*sizeof(double));
                y0 = malloc(N*sizeof(double));
                z0 = malloc(N*sizeof(double));
		aq = malloc(N*sizeof(double));
                bq = malloc(N*sizeof(double));
                cq = malloc(N*sizeof(double));
                x0q = malloc(N*sizeof(double));
                y0q = malloc(N*sizeof(double));
                z0q = malloc(N*sizeof(double));
                p = malloc(N*sizeof(double));
                q = malloc(N*sizeof(double));
                r = malloc(N*sizeof(double));
                h1 = malloc(N*NC*sizeof(double));
                h2 = malloc(N*NC*sizeof(double));
                h3 = malloc(N*NC*sizeof(double));
                hp1 = malloc(N*NC*sizeof(double));
                hp2 = malloc(N*NC*sizeof(double));
                hp3 = malloc(N*NC*sizeof(double));
                pp = malloc(N*NC*sizeof(double));
                qq = malloc(N*NC*sizeof(double));
                rr = malloc(N*NC*sizeof(double));
                pk = malloc(N*NC*sizeof(double));
                qk = malloc(N*NC*sizeof(double));
                rk = malloc(N*NC*sizeof(double));
                x1 = malloc(N*NC*sizeof(double));
                y1 = malloc(N*NC*sizeof(double));
                z1 = malloc(N*NC*sizeof(double));
                x2 = malloc(N*NC*sizeof(double));
                y2 = malloc(N*NC*sizeof(double));
                z2 = malloc(N*NC*sizeof(double));
                tha0 = malloc(N*NC*sizeof(double));
                tha = malloc(N*NC*sizeof(double));
                tha2 = malloc(N*NC*sizeof(double));
                sum = malloc(N*sizeof(double));
                m = malloc(N*NC*sizeof(double));
 
	
		sprintf(buf, "axis%dA-result.txt", i);	
		in = fopen(buf, "r");
		sprintf(buf, "axis%dA-point.txt", i);	
		in2 = fopen(buf, "r");
		sprintf(buf, "outvecA%d.txt", i);	
		in3 = fopen(buf, "r");
		sprintf(buf, "helixA-term-axis%d.txt", i);	
		in4 = fopen(buf, "r");
		sprintf(buf, "coordi%dA.txt", i);	
		in5 = fopen(buf, "r");
		sprintf(buf, "axis%dB-result.txt", i);	
		in6 = fopen(buf, "r");
		sprintf(buf, "axis%dB-point.txt", i);	
		in7 = fopen(buf, "r");
		sprintf(buf, "helixA-term-point%d.txt", i);	
		in8 = fopen(buf, "r");
		sprintf(buf, "outvecA-new%d.txt", i);	
		in9 = fopen(buf, "r");
		sprintf(buf, "rot%dA.txt", i);		
		out = fopen(buf, "w");
		sprintf(buf, "x2y2z2%dA.txt", i);	
		out1 = fopen(buf, "w");
		sprintf(buf, "tha2-%dA-ary.txt", i);	
		out2 = fopen(buf, "w");
		sprintf(buf, "tha%dA-ary.txt", i);		
		out3 = fopen(buf, "w");
		sprintf(buf, "tha0-%dA-ary.txt", i);		
		out4 = fopen(buf, "w");
		sprintf(buf, "check%dA.txt", i);		
		out5 = fopen(buf, "w");
		sprintf(buf, "ks%dA.txt", i);		
		out6 = fopen(buf, "w");
		
                for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a[j], &b[j], &c[j]);
                        fscanf(in2, "%lf%lf%lf\n", &x0[j], &y0[j], &z0[j]);
                        fscanf(in3, "%lf%lf%lf\n", &p[j], &q[j], &r[j]);
                        fscanf(in6, "%lf%lf%lf\n", &aq[j], &bq[j], &cq[j]);
                        fscanf(in7, "%lf%lf%lf\n", &x0q[j], &y0q[j], &z0q[j]);
                }
                fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in6);                                                                                                            
                fclose(in7);                                                                                                            
		for(j=0; j<N; j++){ 
                        for(k=0; k<NC; k++){
				fscanf(in5, "%lf%lf%lf\n", &x1[NC*j+k], &y1[NC*j+k], &z1[NC*j+k]);  
				fscanf(in4, "%lf%lf%lf\n", &h1[NC*j+k], &h2[NC*j+k], &h3[NC*j+k]);  
				fscanf(in8, "%lf%lf%lf\n", &hp1[NC*j+k], &hp2[NC*j+k], &hp3[NC*j+k]);  
				fscanf(in9, "%lf%lf%lf\n", &pk[NC*j+k], &qk[NC*j+k], &rk[NC*j+k]);  
			}
                }
		fclose(in5);                                                                                                            
		fclose(in4);                                                                                                            
		fclose(in8);                                                                                                            
		fclose(in9);                                                                                                            
		for(j=0; j<N; j++){ 
			sum[j] = 0;		                                                                                                   
			
			for(k=0; k<NC; k++){
				m[NC*j+k] = ((x1[NC*j+k]-hp1[NC*j+k])*h1[NC*j+k]+(y1[NC*j+k]-hp2[NC*j+k])*h2[NC*j+k]+(z1[NC*j+k]-hp3[NC*j+k])*h3[NC*j+k])/(h1[NC*j+k]*h1[NC*j+k]+h2[NC*j+k]*h2[NC*j+k]+h3[NC*j+k]*h3[NC*j+k]); 
				x2[NC*j+k]=hp1[NC*j+k]+m[NC*j+k]*h1[NC*j+k];
      				y2[NC*j+k]=hp2[NC*j+k]+m[NC*j+k]*h2[NC*j+k];
				z2[NC*j+k]=hp3[NC*j+k]+m[NC*j+k]*h3[NC*j+k];
				pp[NC*j+k]=qk[NC*j+k]*(z1[NC*j+k]-z2[NC*j+k])-rk[NC*j+k]*(y1[NC*j+k]-y2[NC*j+k]);	
				qq[NC*j+k]=rk[NC*j+k]*(x1[NC*j+k]-x2[NC*j+k])-pk[NC*j+k]*(z1[NC*j+k]-z2[NC*j+k]);
				rr[NC*j+k]=pk[NC*j+k]*(y1[NC*j+k]-y2[NC*j+k])-qk[NC*j+k]*(x1[NC*j+k]-x2[NC*j+k]);
				fprintf(out5, "%lf %lf %lf\n", pp[NC*j+k],qq[NC*j+k],rr[NC*j+k]);
				fprintf(out6, "%lf\t%lf\t%lf\n", pk[NC*j+k],qk[NC*j+k],rk[NC*j+k]);
				tha0[NC*j+k]=(pp[NC*j+k]*h1[NC*j+k]+qq[NC*j+k]*h2[NC*j+k]+rr[NC*j+k]*h3[NC*j+k])/sqrt((pp[NC*j+k]*pp[NC*j+k]+qq[NC*j+k]*qq[NC*j+k]+rr[NC*j+k]*rr[NC*j+k])*(h1[NC*j+k]*h1[NC*j+k]+h2[NC*j+k]*h2[NC*j+k]+h3[NC*j+k]*h3[NC*j+k]));
				tha[NC*j+k]=acos((pk[NC*j+k]*(x1[NC*j+k]-x2[NC*j+k])+qk[NC*j+k]*(y1[NC*j+k]-y2[NC*j+k])+rk[NC*j+k]*(z1[NC*j+k]-z2[NC*j+k]))/sqrt((pk[NC*j+k]*pk[NC*j+k]+qk[NC*j+k]*qk[NC*j+k]+rk[NC*j+k]*rk[NC*j+k])*((x1[NC*j+k]-x2[NC*j+k])*(x1[NC*j+k]-x2[NC*j+k])+(y1[NC*j+k]-y2[NC*j+k])*(y1[NC*j+k]-y2[NC*j+k])+(z1[NC*j+k]-z2[NC*j+k])*(z1[NC*j+k]-z2[NC*j+k]))));				
				if(tha0[NC*j+k]>0){
					tha[NC*j+k] = tha[NC*j+k];
				}
				else{
					tha[NC*j+k] = 2*M_PI-tha[NC*j+k];
				}
				fprintf(out1, "%lf %lf %lf\n", x2[NC*j+k],y2[NC*j+k],z2[NC*j+k]);
 				fprintf(out3, "%lf\n", 180*tha[NC*j+k]/M_PI);

				tha2[NC*j+k] = tha[NC*j+k]-tha[k];
 				fprintf(out4, "%lf\n", tha0[NC*j+k]);
									
				if(k>24){
					tha2[NC*j+k]=0;
				}
				else{
					tha2[NC*j+k] = tha2[NC*j+k];
				}
		 		fprintf(out2, "%lf\n", 180*tha2[NC*j+k]/M_PI);
			}
  		}
			
                fclose(out); 
                fclose(out1); 
                fclose(out2); 
                fclose(out3); 
                fclose(out4); 
                fclose(out5); 
                fclose(out6); 
		free(x2);
		free(y2);
		free(z2);
		free(tha);
		free(tha0);
		free(tha2);
		free(sum);
	} 
	return 0;                                                                                                         
}        
		
int rotBrevise()
{
	int i,j,k;
	FILE *out6,*out5,*in9,*in, *out, *in2, *in3, *in4,*in5, *in6, *in7, *in8, *out1, *out2, *out3, *out4;
	double *m,*pk,*qk,*rk,*hp1, *hp2, *hp3, *h1, *h2, *h3, *t, *tq, *deld, *dele, *delf, *pp, *qq, *rr, *tha0, *tha2, *sum,*tha,*a,*b,*c,*aq,*bq,*cq,*x0,*y0,*z0, *x1,*y1,*z1,*x2,*y2,*z2,*p,*q,*r, *x0q, *y0q, *z0q;
	char C;
	char buf[1000];
	int NC=28;
	
	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "coordi%dB.txt", i);
		in = fopen(buf, "r");
			while((C=fgetc(in)) != EOF){
				if(C == '\n'){
					N++;
				}
			}
		N = N/NC;
		printf("%d\n", N);
		fclose(in);
                
		t = malloc(N*sizeof(double));
                tq = malloc(N*sizeof(double));
		deld = malloc(N*sizeof(double));
                dele = malloc(N*sizeof(double));
                delf = malloc(N*sizeof(double));
		a = malloc(N*sizeof(double));
                b = malloc(N*sizeof(double));
                c = malloc(N*sizeof(double));
                x0 = malloc(N*sizeof(double));
                y0 = malloc(N*sizeof(double));
                z0 = malloc(N*sizeof(double));
		aq = malloc(N*sizeof(double));
                bq = malloc(N*sizeof(double));
                cq = malloc(N*sizeof(double));
                x0q = malloc(N*sizeof(double));
                y0q = malloc(N*sizeof(double));
                z0q = malloc(N*sizeof(double));
                p = malloc(N*sizeof(double));
                q = malloc(N*sizeof(double));
                r = malloc(N*sizeof(double));
                h1 = malloc(N*NC*sizeof(double));
                h2 = malloc(N*NC*sizeof(double));
                h3 = malloc(N*NC*sizeof(double));
                hp1 = malloc(N*NC*sizeof(double));
                hp2 = malloc(N*NC*sizeof(double));
                hp3 = malloc(N*NC*sizeof(double));
                pp = malloc(N*NC*sizeof(double));
                qq = malloc(N*NC*sizeof(double));
                rr = malloc(N*NC*sizeof(double));
                pk = malloc(N*NC*sizeof(double));
                qk = malloc(N*NC*sizeof(double));
                rk = malloc(N*NC*sizeof(double));
                x1 = malloc(N*NC*sizeof(double));
                y1 = malloc(N*NC*sizeof(double));
                z1 = malloc(N*NC*sizeof(double));
                x2 = malloc(N*NC*sizeof(double));
                y2 = malloc(N*NC*sizeof(double));
                z2 = malloc(N*NC*sizeof(double));
                tha0 = malloc(N*NC*sizeof(double));
                tha = malloc(N*NC*sizeof(double));
                tha2 = malloc(N*NC*sizeof(double));
                sum = malloc(N*sizeof(double));
                m = malloc(N*NC*sizeof(double));
 
	
		sprintf(buf, "axis%dB-result.txt", i);	
		in = fopen(buf, "r");
		sprintf(buf, "axis%dB-point.txt", i);	
		in2 = fopen(buf, "r");
		sprintf(buf, "outvecB%d.txt", i);	
		in3 = fopen(buf, "r");
		sprintf(buf, "helixB-term-axis%d.txt", i);	
		in4 = fopen(buf, "r");
		sprintf(buf, "coordi%dB.txt", i);	
		in5 = fopen(buf, "r");
		sprintf(buf, "axis%dA-result.txt", i);	
		in6 = fopen(buf, "r");
		sprintf(buf, "axis%dA-point.txt", i);	
		in7 = fopen(buf, "r");
		sprintf(buf, "helixB-term-point%d.txt", i);	
		in8 = fopen(buf, "r");
		sprintf(buf, "outvecB-new%d.txt", i);	
		in9 = fopen(buf, "r");
		sprintf(buf, "rot%dB.txt", i);		
		out = fopen(buf, "w");
		sprintf(buf, "x2y2z2%dB.txt", i);	
		out1 = fopen(buf, "w");
		sprintf(buf, "tha2-%dB-ary.txt", i);	
		out2 = fopen(buf, "w");
		sprintf(buf, "tha%dB-ary.txt", i);		
		out3 = fopen(buf, "w");
		sprintf(buf, "tha0-%dB-ary.txt", i);		
		out4 = fopen(buf, "w");
		sprintf(buf, "check%dB.txt", i);		
		out5 = fopen(buf, "w");
		sprintf(buf, "ks%dB.txt", i);		
		out6 = fopen(buf, "w");
		
                for(j=0; j<N; j++){ 
                        fscanf(in, "%lf%lf%lf\n", &a[j], &b[j], &c[j]);
                        fscanf(in2, "%lf%lf%lf\n", &x0[j], &y0[j], &z0[j]);
                        fscanf(in3, "%lf%lf%lf\n", &p[j], &q[j], &r[j]);
                        fscanf(in6, "%lf%lf%lf\n", &aq[j], &bq[j], &cq[j]);
                        fscanf(in7, "%lf%lf%lf\n", &x0q[j], &y0q[j], &z0q[j]);
                }
                fclose(in);                                                                                                            
                fclose(in2);                                                                                                            
                fclose(in3);                                                                                                            
                fclose(in6);                                                                                                            
                fclose(in7);                                                                                                            
		for(j=0; j<N; j++){ 
                        for(k=0; k<NC; k++){
				fscanf(in5, "%lf%lf%lf\n", &x1[NC*j+k], &y1[NC*j+k], &z1[NC*j+k]);  
				fscanf(in4, "%lf%lf%lf\n", &h1[NC*j+k], &h2[NC*j+k], &h3[NC*j+k]);  
				fscanf(in8, "%lf%lf%lf\n", &hp1[NC*j+k], &hp2[NC*j+k], &hp3[NC*j+k]);  
				fscanf(in9, "%lf%lf%lf\n", &pk[NC*j+k], &qk[NC*j+k], &rk[NC*j+k]);  
			}
                }
		fclose(in5);                                                                                                            
		fclose(in4);                                                                                                            
		fclose(in8);                                                                                                            
		fclose(in9);                                                                                                            
		for(j=0; j<N; j++){ 
			sum[j] = 0;		                                                                                                   
			
			for(k=0; k<NC; k++){
				m[NC*j+k] = ((x1[NC*j+k]-hp1[NC*j+k])*h1[NC*j+k]+(y1[NC*j+k]-hp2[NC*j+k])*h2[NC*j+k]+(z1[NC*j+k]-hp3[NC*j+k])*h3[NC*j+k])/(h1[NC*j+k]*h1[NC*j+k]+h2[NC*j+k]*h2[NC*j+k]+h3[NC*j+k]*h3[NC*j+k]); 
				x2[NC*j+k]=hp1[NC*j+k]+m[NC*j+k]*h1[NC*j+k];
      				y2[NC*j+k]=hp2[NC*j+k]+m[NC*j+k]*h2[NC*j+k];
				z2[NC*j+k]=hp3[NC*j+k]+m[NC*j+k]*h3[NC*j+k];
				pp[NC*j+k]=qk[NC*j+k]*(z1[NC*j+k]-z2[NC*j+k])-rk[NC*j+k]*(y1[NC*j+k]-y2[NC*j+k]);	
				qq[NC*j+k]=rk[NC*j+k]*(x1[NC*j+k]-x2[NC*j+k])-pk[NC*j+k]*(z1[NC*j+k]-z2[NC*j+k]);
				rr[NC*j+k]=pk[NC*j+k]*(y1[NC*j+k]-y2[NC*j+k])-qk[NC*j+k]*(x1[NC*j+k]-x2[NC*j+k]);
				fprintf(out5, "%lf %lf %lf\n", pp[NC*j+k],qq[NC*j+k],rr[NC*j+k]);
				fprintf(out6, "%lf %lf %lf\n", h1[NC*j+k],h2[NC*j+k],h3[NC*j+k]);
				tha0[NC*j+k]=(pp[NC*j+k]*h1[NC*j+k]+qq[NC*j+k]*h2[NC*j+k]+rr[NC*j+k]*h3[NC*j+k])/sqrt((pp[NC*j+k]*pp[NC*j+k]+qq[NC*j+k]*qq[NC*j+k]+rr[NC*j+k]*rr[NC*j+k])*(h1[NC*j+k]*h1[NC*j+k]+h2[NC*j+k]*h2[NC*j+k]+h3[NC*j+k]*h3[NC*j+k]));
				tha[NC*j+k]=acos((pk[NC*j+k]*(x1[NC*j+k]-x2[NC*j+k])+qk[NC*j+k]*(y1[NC*j+k]-y2[NC*j+k])+rk[NC*j+k]*(z1[NC*j+k]-z2[NC*j+k]))/sqrt((pk[NC*j+k]*pk[NC*j+k]+qk[NC*j+k]*qk[NC*j+k]+rk[NC*j+k]*rk[NC*j+k])*((x1[NC*j+k]-x2[NC*j+k])*(x1[NC*j+k]-x2[NC*j+k])+(y1[NC*j+k]-y2[NC*j+k])*(y1[NC*j+k]-y2[NC*j+k])+(z1[NC*j+k]-z2[NC*j+k])*(z1[NC*j+k]-z2[NC*j+k]))));				
				if(tha0[NC*j+k]>0){
					tha[NC*j+k] = tha[NC*j+k];
				}
				else{
					tha[NC*j+k] = 2*M_PI-tha[NC*j+k];
				}
				fprintf(out1, "%lf %lf %lf\n", x2[NC*j+k],y2[NC*j+k],z2[NC*j+k]);
 				fprintf(out3, "%lf\n", 180*tha[NC*j+k]/M_PI);

				tha2[NC*j+k] = tha[NC*j+k]-tha[k];
 				fprintf(out4, "%lf\n", tha0[NC*j+k]);
									
				if(k>24){
					tha2[NC*j+k]=0;
				}
				else{
					tha2[NC*j+k] = tha2[NC*j+k];
				}
		 		fprintf(out2, "%lf\n", 180*tha2[NC*j+k]/M_PI);
			}
  		}
			
                fclose(out); 
                fclose(out1); 
                fclose(out2); 
                fclose(out3); 
                fclose(out4); 
                fclose(out5); 
                fclose(out6); 
		free(x2);
		free(y2);
		free(z2);
		free(tha);
		free(tha0);
		free(tha2);
		free(sum);
	} 
	return 0;                                                                                                         
}        
		
int rotAperiod()
{
	int i,j,k,s;
	FILE *in, *out, *out2;
	double *tha2, *sum;
	double pro,near;
	char C;
	char buf[1000];
	int NC=28;
	
	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "tha2-%dA-ary.txt", i);
		in = fopen(buf, "r");
			while((C=fgetc(in)) != EOF){
				if(C == '\n'){
					N++;
				}
			}
		N = N/NC;
		printf("%d\n", N);
		fclose(in);
		
		tha2 = malloc(N*NC*sizeof(double));
		sum = malloc(N*sizeof(double));
    
		sprintf(buf, "tha2-%dA-ary.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		for(j=0; j<N;j++){
			for(k=0;k<NC;k++){
				fscanf(in, "%lf\n",  &tha2[NC*j+k]);
			}
		}
		fclose(in);
		sprintf(buf, "tha2-%dA-ary.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "rot-sum%dA.txt", i);   
                out = fopen(buf, "w"); 
    		
		sprintf(buf, "rot%dA.txt", i);   
                out2 = fopen(buf, "w"); 
    		
		for(j=0; j<N;j++){
			sum[j] =0;
			for(k=0;k<NC-3;k++){
    	    	    			double a[3] = {tha2[NC*j+k+1]-360,tha2[NC*j+k+1],tha2[NC*j+k+1]+360};					
    	    	    			double pro_ref = 13100;
    	    	    			 for(s=0;s<3;s++){
    	    	    				if(tha2[NC*j+k]>a[s]){
    	    	    					pro = tha2[NC*j+k]-a[s];
    	    	    				}
    	    	    				else{
    	    	    					pro = -tha2[NC*j+k]+a[s];
    	    	    				}
    	    	    				if(pro_ref >= pro){
    	    	    					pro_ref=pro;
    	    	    				 	near = a[s];
    	    	    				}
    	    	    			}
					tha2[NC*j+k+1] = near;
    				fprintf(out, "%lf\n", tha2[NC*j+k]);
				sum[j] = sum[j] + tha2[NC*j+k];
			}
			sum[j] = sum[j]/((NC));
			if(sum[j]>=0){
				sum[j]=sum[j];
			}
			else{
				sum[j]=360+sum[j];
			}
			fprintf(out2, "%lf\n",  sum[j]);                                                  
		}
		fclose(in);
		fclose(out);
		fclose(out2);
	}
	return 0;
}

int rotBperiod()
{
	int i,j,k,s;
	FILE *in, *out, *out2;
	double *tha2, *sum;
	double pro,near;
	char C;
	char buf[1000];
	int NC=28;
	
	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "tha2-%dB-ary.txt", i);
		in = fopen(buf, "r");
			while((C=fgetc(in)) != EOF){
				if(C == '\n'){
					N++;
				}
			}
		N = N/NC;
		printf("%d\n", N);
		fclose(in);
		
		tha2 = malloc(N*NC*sizeof(double));
		sum = malloc(N*sizeof(double));
    
		sprintf(buf, "tha2-%dB-ary.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		for(j=0; j<N;j++){
			for(k=0;k<NC;k++){
				fscanf(in, "%lf\n",  &tha2[NC*j+k]);
			}
		}
		fclose(in);
		sprintf(buf, "tha2-%dB-ary.txt", i);         
		in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "rot-sum%dB.txt", i);   
                out = fopen(buf, "w"); 
    		
		sprintf(buf, "rot%dB.txt", i);   
                out2 = fopen(buf, "w"); 
    		
		for(j=0; j<N;j++){
			sum[j] =0;
			for(k=0;k<NC-3;k++){
    	    	    			double a[3] = {tha2[NC*j+k+1]-360,tha2[NC*j+k+1],tha2[NC*j+k+1]+360};					
    	    	    			double pro_ref = 13100;
    	    	    			 for(s=0;s<3;s++){
    	    	    				if(tha2[NC*j+k]>a[s]){
    	    	    					pro = tha2[NC*j+k]-a[s];
    	    	    				}
    	    	    				else{
    	    	    					pro = -tha2[NC*j+k]+a[s];
    	    	    				}
    	    	    				if(pro_ref >= pro){
    	    	    					pro_ref=pro;
    	    	    				 	near = a[s];
    	    	    				}
    	    	    			}
					tha2[NC*j+k+1] = near;
    				fprintf(out, "%lf\n", tha2[NC*j+k]);
				sum[j] = sum[j] + tha2[NC*j+k];
			}
			sum[j] = sum[j]/((NC));
			if(sum[j]>=0){
				sum[j]=sum[j];
			}
			else{
				sum[j]=360+sum[j];
			}
			fprintf(out2, "%lf\n",  sum[j]);                                                 
		}
		fclose(in);
		fclose(out);
		fclose(out2);
	}
	return 0;
}

int convrot()
{
	int i, j, k;
	FILE *in, *out, *in2;
	double x,y;
	char c;
	char buf[256];

	for(i=100; i<101; i++){
		int N=0;
		sprintf(buf, "rot%dA.txt", i);
		in = fopen(buf, "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

		sprintf(buf, "rot%dA.txt", i);                                                                              
                in = fopen(buf, "r");                                                                                                  
		sprintf(buf, "rot%dB.txt", i);                                                                              
                in2 = fopen(buf, "r");                                                                                                  
		sprintf(buf, "rot%d.txt", i);                                                                                 
                out = fopen(buf, "w"); 
                for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf\n", &x);
                        fscanf(in2, "%lf\n", &y);
                        fprintf(out, "%lf\t%lf\n", x,y);
		}	
			
                fclose(in);                                                                                                            
                fclose(out); 
		} 
	return 0;                                                                                                         
}        

int periodA()
{                                                                                                                                      
        int i,j,k;                                                                                                                       
        FILE *in, *in2, *out;                                                                                                                
        double x,y,z, sum, sumy, d1, d2, t1, t2,pro,near;
 	double *r1, *r2;
  	char buf[256];
	char c;

        for(i=100; i<101; i++){      
                sprintf(buf, "rot%dA.txt",i);
		in = fopen(buf, "r");                                                                                                  
			int N = 0;
			while((c = fgetc(in)) != EOF){
				if(c == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);                                                                                                            
		r1 = malloc(N*sizeof(double));
	
                sprintf(buf, "rot%dA.txt",i);
		in = fopen(buf, "r");  
  
		for(j=0; j<N; j++){
			fscanf(in, "%lf\n",  &r1[j]);
		}
		fclose(in);
                sprintf(buf, "rot%dA.txt",i);
		in = fopen(buf, "r");  
                sprintf(buf, "rot-period%dA.txt",i);
		out = fopen(buf, "w");
		for(j=0; j<N-1; j++){
			double a[87] = {r1[j+1]-15480,r1[j+1]-15120,r1[j+1]-14760,r1[j+1]-14400,r1[j+1]-14040,r1[j+1]-13680,r1[j+1]-13320,r1[j+1]-12960,r1[j+1]-12600,r1[j+1]-12240,r1[j+1]-11880,r1[j+1]-11520,r1[j+1]-11160,r1[j+1]-10800,r1[j+1]-10440,r1[j+1]-10080,r1[j+1]-9720,r1[j+1]-9360,r1[j+1]-9000,r1[j+1]-8640,r1[j+1]-8280,r1[j+1]-7920,r1[j+1]-7560,r1[j+1]-7200,r1[j+1]-6840,r1[j+1]-6480,r1[j+1]-6120,r1[j+1]-5760,r1[j+1]-5400,r1[j+1]-5040,r1[j+1]-4680,r1[j+1]-4320,r1[j+1]-3960,r1[j+1]-3600,r1[j+1]-3240,r1[j+1]-2880,r1[j+1]-2520,r1[j+1]-2160,r1[j+1]-1800,r1[j+1]-1440,r1[j+1]-1080,r1[j+1]-720, r1[j+1]-360,r1[j+1],r1[j+1]+360,r1[j+1]+720,r1[j+1]+1080,r1[j+1]+1440,r1[j+1]+1800,r1[j+1]+2160,r1[j+1]+2520,r1[j+1]+2880,r1[j+1]+3240,r1[j+1]+3600,r1[j+1]+3960,r1[j+1]+4320,r1[j+1]+4680,r1[j+1]+5040,r1[j+1]+5400,r1[j+1]+5760,r1[j+1]+6120,r1[j+1]+6480,r1[j+1]+6840,r1[j+1]+7200,r1[j+1]+7560,r1[j+1]+7920,r1[j+1]+8280,r1[j+1]+8640,r1[j+1]+9000,r1[j+1]+9360,r1[j+1]+9720,r1[j+1]+10080,r1[j+1]+10440,r1[j+1]+10800,r1[j+1]+11160,r1[j+1]+11520,r1[j+1]+11880,r1[j+1]+12240,r1[j+1]+12600,r1[j+1]+12960,r1[j+1]+13320,r1[j+1]+13680,r1[j+1]+14040,r1[j+1]+14400,r1[j+1]+14760,r1[j+1]+15120,r1[j+1]+15480};		
			double pro_ref=150000;
			for(k=0;k<87;k++){
				if(r1[j]>a[k]){
					pro = r1[j]-a[k];
				}
				else{
					pro = a[k]-r1[j];
				}
				if(pro_ref>=pro){
					pro_ref=pro;
					near = a[k];
				}
			}
			r1[j+1]=near;		
			fprintf(out, "%lf\n", near);
		}
		fclose(in);
		fclose(out);
	}
	return 0;
}

int periodB()
{                                                                                                                                      
        int i,j,k;                                                                                                                       
        FILE *in, *in2, *out;                                                                                                                
        double x,y,z, sum, sumy, d1, d2, t1, t2,pro,near;
 	double *r1, *r2;
  	char buf[256];
	char c;

        for(i=100; i<101; i++){      
                sprintf(buf, "rot%dB.txt",i);
		in = fopen(buf, "r");                                                                                                  
			int N = 0;
			while((c = fgetc(in)) != EOF){
				if(c == '\n'){ 
					N++;
				}
			}
		printf("%d\n", N);
                fclose(in);                                                                                                            
		r1 = malloc(N*sizeof(double));
	
                sprintf(buf, "rot%dB.txt",i);
		in = fopen(buf, "r");  
  
		for(j=0; j<N; j++){
			fscanf(in, "%lf\n",  &r1[j]);
		}
		fclose(in);
                sprintf(buf, "rot%dB.txt",i);
		in = fopen(buf, "r");  
                sprintf(buf, "rot-period%dB.txt",i);
		out = fopen(buf, "w");
		for(j=0; j<N-1; j++){
			double a[87] = {r1[j+1]-15480,r1[j+1]-15120,r1[j+1]-14760,r1[j+1]-14400,r1[j+1]-14040,r1[j+1]-13680,r1[j+1]-13320,r1[j+1]-12960,r1[j+1]-12600,r1[j+1]-12240,r1[j+1]-11880,r1[j+1]-11520,r1[j+1]-11160,r1[j+1]-10800,r1[j+1]-10440,r1[j+1]-10080,r1[j+1]-9720,r1[j+1]-9360,r1[j+1]-9000,r1[j+1]-8640,r1[j+1]-8280,r1[j+1]-7920,r1[j+1]-7560,r1[j+1]-7200,r1[j+1]-6840,r1[j+1]-6480,r1[j+1]-6120,r1[j+1]-5760,r1[j+1]-5400,r1[j+1]-5040,r1[j+1]-4680,r1[j+1]-4320,r1[j+1]-3960,r1[j+1]-3600,r1[j+1]-3240,r1[j+1]-2880,r1[j+1]-2520,r1[j+1]-2160,r1[j+1]-1800,r1[j+1]-1440,r1[j+1]-1080,r1[j+1]-720, r1[j+1]-360,r1[j+1],r1[j+1]+360,r1[j+1]+720,r1[j+1]+1080,r1[j+1]+1440,r1[j+1]+1800,r1[j+1]+2160,r1[j+1]+2520,r1[j+1]+2880,r1[j+1]+3240,r1[j+1]+3600,r1[j+1]+3960,r1[j+1]+4320,r1[j+1]+4680,r1[j+1]+5040,r1[j+1]+5400,r1[j+1]+5760,r1[j+1]+6120,r1[j+1]+6480,r1[j+1]+6840,r1[j+1]+7200,r1[j+1]+7560,r1[j+1]+7920,r1[j+1]+8280,r1[j+1]+8640,r1[j+1]+9000,r1[j+1]+9360,r1[j+1]+9720,r1[j+1]+10080,r1[j+1]+10440,r1[j+1]+10800,r1[j+1]+11160,r1[j+1]+11520,r1[j+1]+11880,r1[j+1]+12240,r1[j+1]+12600,r1[j+1]+12960,r1[j+1]+13320,r1[j+1]+13680,r1[j+1]+14040,r1[j+1]+14400,r1[j+1]+14760,r1[j+1]+15120,r1[j+1]+15480};		
			double pro_ref=150000;
			for(k=0;k<87;k++){
				if(r1[j]>a[k]){
					pro = r1[j]-a[k];
				}
				else{
					pro = a[k]-r1[j];
				}
				if(pro_ref>=pro){
					pro_ref=pro;
					near = a[k];
				}
			}
			r1[j+1]=near;		
			fprintf(out, "%lf\n", near);
		}
		fclose(in);
		fclose(out);
	}
	return 0;
}

int main()
{
	middlepoint();
	makeaxisA();
	makeaxisB();
	extaxisA();
	extaxisB();
	outvectest();
	ca();
	outvecA();
	outvecB();
	outvecrevise();
	helixAterm();
	helixBterm();
	outvecnew();
	deldistance();
	rotArevise();
	rotBrevise();
	rotAperiod();
	rotBperiod();
	convrot();
	periodA();
	periodB();
}
